# Copyright (c) 2025, SRIAAS and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSRPatientDisableReason(FrappeTestCase):
	pass
