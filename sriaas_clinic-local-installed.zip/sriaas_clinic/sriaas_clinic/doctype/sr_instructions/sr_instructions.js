// Copyright (c) 2025, SRIAAS and contributors
// For license information, please see license.txt

// frappe.ui.form.on("SR Instructions", {
// 	refresh(frm) {

// 	},
// });
